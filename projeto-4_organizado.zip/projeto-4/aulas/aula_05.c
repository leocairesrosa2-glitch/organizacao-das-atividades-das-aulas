/*
 * Nome: LEONARDO CAIRES ROSA
 * RGM : 48123676
 *
 * Aula 5 - Valor da hospedagem (switch)
 *
 * Lê o tipo de hospedagem e a quantidade de diárias e calcula o total.
 *   S (solteiro) = R$ 300,00 | D (duplo) = R$ 450,00 | T (triplo) = R$ 500,00
 */
#include <stdio.h>

#define DIARIA_SIMPLES 300.0f
#define DIARIA_DUPLO   450.0f
#define DIARIA_TRIPLO  500.0f

int main(void) {
    char tipo = ' ';
    int diarias = 0;
    float valor, total;

    printf("Qual o tipo de hospedagem (S-D-T)? ");
    scanf(" %c", &tipo);

    printf("Qual a quantidade de diarias? ");
    scanf("%d", &diarias);

    if (diarias <= 0) {
        printf("Quantidade de diarias invalida!\n");
        return 1;
    }

    switch (tipo) {
        case 'S':
        case 's':
            valor = DIARIA_SIMPLES;
            break;
        case 'D':
        case 'd':
            valor = DIARIA_DUPLO;
            break;
        case 'T':
        case 't':
            valor = DIARIA_TRIPLO;
            break;
        default:
            printf("Tipo invalido!!!\n");
            return 1;
    }

    total = valor * diarias;

    printf("Valor total a pagar: R$ %.2f\n", total);

    return 0;
}
