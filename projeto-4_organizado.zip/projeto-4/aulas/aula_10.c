/*
 * Nome: LEONARDO CAIRES ROSA
 * RGM : 48123676
 *
 * Aula 10 - Ordenação com Bubble Sort (funções e vetores)
 *
 * Ordena um vetor de senhas em ordem crescente usando o Bubble Sort
 * e mostra o vetor antes e depois da ordenação.
 */
#include <stdio.h>

/* Mostra os elementos do vetor na tela */
void exibirVetor(int vetor[], int tamanho) {
    int i;

    for (i = 0; i < tamanho; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");
}

/* Ordena o vetor em ordem crescente (Bubble Sort) */
void bubbleSort(int vetor[], int tamanho) {
    int i, j, auxiliar;

    for (i = 0; i < tamanho - 1; i++) {
        for (j = 0; j < tamanho - 1 - i; j++) {
            if (vetor[j] > vetor[j + 1]) {
                auxiliar = vetor[j];
                vetor[j] = vetor[j + 1];
                vetor[j + 1] = auxiliar;
            }
        }
    }
}

int main(void) {
    int senhas[] = {35, 12, 58, 7, 19};
    int tamanho = sizeof(senhas) / sizeof(senhas[0]);

    printf("Senhas antes da ordenação:\n");
    exibirVetor(senhas, tamanho);

    bubbleSort(senhas, tamanho);

    printf("Senhas depois da ordenação:\n");
    exibirVetor(senhas, tamanho);

    return 0;
}
