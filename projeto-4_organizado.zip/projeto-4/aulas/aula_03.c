/*
 * Nome: LEONARDO CAIRES ROSA
 * RGM : 48123676
 *
 * Aula 3 - Perímetro da circunferência
 *
 * Lê o raio de uma peça (em centímetros) e calcula o perímetro
 * da circunferência: 2 * PI * raio.
 */
#include <stdio.h>

int main(void) {
    const double PI = 3.14159;
    double raio = 0, perimetro;

    printf("Digite o raio da peça em centímetros: ");
    scanf("%lf", &raio);

    if (raio < 0) {
        printf("Raio inválido! Digite um valor maior ou igual a zero.\n");
        return 1;
    }

    perimetro = 2 * PI * raio;

    printf("Perímetro da circunferência: %.2f cm\n", perimetro);

    return 0;
}
